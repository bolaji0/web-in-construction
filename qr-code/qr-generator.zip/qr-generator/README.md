# Platen — QR Code Generator

A print-focused QR code generator. Plain HTML/CSS/JS, zero build step, zero
runtime dependencies, zero cost.

## What it does

- Encodes any text/URL into a QR code (versions 1–40, all four error
  correction levels).
- Live preview rendered on a "proof sheet" with print registration marks.
- Export formats:
  - **PNG / JPG / WebP** — raster, sized either in screen pixels or in real
    millimetres at 150/300/600 DPI.
  - **SVG** — true vector, row-merged rectangles, sized in millimetres.
  - **PDF** — true vector, built by hand (no library) as a single-page PDF
    sized exactly to your chosen physical dimensions. This is what you hand
    to a card bureau or NFC/plastic-card printer — it never blurs, at any
    scale.
- Custom ink/stock colors with a contrast warning, transparent background
  option, adjustable quiet zone.

## How it's built

- `vendor/qrcodegen.js` — the QR matrix math (mode selection, Reed–Solomon
  error correction, masking, module placement). This is Project Nayuki's
  QR Code generator library, MIT licensed, compiled here from its
  TypeScript source to a single plain-JS file so it runs with no build step
  and no network call. Getting the Reed–Solomon/masking stages *exactly*
  spec-correct is the one part of a QR generator worth not re-deriving by
  hand — a subtly wrong implementation still *looks* like a QR code but
  fails to scan, which is a bad failure mode for cards you've already
  printed. Swap this file out any time if you'd rather roll your own.
- `index.html`, `style.css`, `script.js` — everything else (UI, canvas
  rendering, the SVG builder, and the from-scratch vector PDF writer) is
  original to this build.

Both the SVG and PDF export paths were verified by rendering them back to
an image and decoding the QR to confirm the payload round-trips correctly.

## Running it

No install, no server required:

```bash
# from this folder
python3 -m http.server 8000
# open http://localhost:8000
```

Or just double-click `index.html` — everything works from the `file://`
protocol too, since there are no network calls at all.

## Deploying it for free

Any static host works since this is just three files + one vendored
library:

- **GitHub Pages** — push this folder to a repo, enable Pages in repo
  settings. Free, no account beyond GitHub.
- **Cloudflare Pages** — drag-and-drop deploy from the dashboard. Free tier
  has no meaningful traffic cap for a tool like this.
- **Netlify** — same drag-and-drop free tier.

All three give you a public URL and free HTTPS with no credit card.

## Roadmap ideas (not built yet)

- Center-logo overlay (needs forcing ECC to Q/H and a "quiet zone around
  the logo" carve-out — the QR spec tolerates this because it's just extra
  simulated damage, but it needs testing per logo size).
- Batch mode: paste a CSV of many URLs, get a zip of individually named
  PDFs (useful if you're printing a numbered run of NFC cards).
- vCard / Wi-Fi / email quick-fill templates that format the input string
  for you.
- A4/Letter sheet layout mode that tiles many QR codes with crop marks for
  print-and-cut runs.

## License

`vendor/qrcodegen.js`: MIT License, Copyright (c) Project Nayuki.
Everything else in this folder: do whatever you want with it.
